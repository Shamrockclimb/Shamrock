export const mockAttendance = [
  { userId: 1, date: '2023-07-10', eventId: 1, role: 'student' },
  { userId: 1, date: '2023-07-12', eventId: 2, role: 'student' },
  { userId: 2, date: '2023-07-10', eventId: 1, role: 'instructor', hours: 1.5 },
  { userId: 2, date: '2023-07-12', eventId: 2, role: 'instructor', hours: 2 },
  { userId: 3, date: '2023-07-10', eventId: 1, role: 'director' },
];