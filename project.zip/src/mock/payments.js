export const mockPayments = [
  { userId: 1, month: '2023-07', paid: true },
  { userId: 1, month: '2023-08', paid: false },
  { userId: 2, month: '2023-07', paid: true },
  { userId: 3, month: '2023-07', paid: true },
];