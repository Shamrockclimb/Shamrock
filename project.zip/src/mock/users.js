export const mockUsers = [
  {
    id: 1,
    name: 'Juan Pérez',
    email: 'juan.perez@shamrock.com',
    password: 'password123',
    age: 25,
    level: 'intermediate',
    role: 'student'
  },
  {
    id: 2,
    name: 'Ana García',
    email: 'ana.garcia@shamrock.com',
    password: 'securepassword',
    age: 30,
    level: 'advanced',
    role: 'instructor'
  },
  {
    id: 3,
    name: 'Carlos López',
    email: 'carlos.lopez@shamrock.com',
    password: 'adminpassword',
    age: 45,
    level: 'expert',
    role: 'director'
  }
];